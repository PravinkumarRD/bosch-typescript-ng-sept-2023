using Bajaj.Events.Api.Jwt;
using Bajaj.Events.Dal;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//With AddDbContext() method, we can now inject the DbContext anywhere in our application.
builder.Services.AddDbContext<EventManagementDbContext>(context =>
{
    context.UseSqlServer(builder.Configuration.GetConnectionString("BajajEventDbConStr"));
});

builder.Services.AddTransient<ICommonRepository<Employee>, CommonRepository<Employee>>();
builder.Services.AddTransient<ICommonRepository<Role>, CommonRepository<Role>>();
builder.Services.AddTransient<ICommonRepository<User>, CommonRepository<User>>();
builder.Services.AddTransient<ICommonRepository<Event>, CommonRepository<Event>>();
builder.Services.AddTransient<ISecurity, Security>();
builder.Services.AddTransient<ITokenManager, TokenManager>();
builder.Services.AddControllers();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["BajajJwtSettings:Secret"])),
        ValidateIssuer = false,
        ValidateAudience = false,
    };
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("BajajCorsPolicy", policy =>
    {
        policy.AllowAnyHeader();
        policy.AllowAnyMethod();
        policy.AllowAnyOrigin();
    });
});
string bajajCorePolicy = "BajajCorsPolicy";
builder.Services.AddCors(options =>
{
    options.AddPolicy(name:bajajCorePolicy, policy =>
    {
        policy.WithOrigins("http://127.0.0.1:5500", "http://localhost:4200");
        policy.AllowAnyHeader();
        policy.AllowAnyMethod();
    });
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Authentication Token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JsonWebToken",
        Scheme = "Bearer"
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
    });
});
var app = builder.Build();

app.UseCors(bajajCorePolicy);
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
