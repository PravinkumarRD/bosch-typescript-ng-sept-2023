﻿using Bajaj.Events.Dal;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Events.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly ICommonRepository<Role> _roleRepository;

        public RolesController(ICommonRepository<Role> roleRepository)
        {
            _roleRepository = roleRepository;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Role>>> GetAllRoles()
        {
            var roles = await _roleRepository.GetAll();
            if (roles.Count > 0)
            {
                return Ok(roles);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Role>> GetRoleDetails(int id)
        {
            var role = await _roleRepository.GetDetails(id);
            if (role != null)
            {
                return Ok(role);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> AddRole(Role role)
        {
            if (ModelState.IsValid)
            {
                int result = await _roleRepository.Insert(role);
                if (result > 0)
                {
                    return CreatedAtAction("GetRoleDetails", new { id = role.RoleId }, role);
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> UpdateRole(Role role)
        {
            if (ModelState.IsValid)
            {
                var result = await _roleRepository.Update(role);

                if (result > 0)
                {
                    return NoContent();
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<int>> DeleteRole(int id)
        {
            var result = await _roleRepository.Delete(id);
            if (result > 0)
            {
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
    }
}
