﻿using Bajaj.Events.Dal;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Events.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors(policyName: "BajajCorsPolicy")]
    public class EventsController : ControllerBase
    {
        private readonly ICommonRepository<Event> _eventRepository;

        public EventsController(ICommonRepository<Event> eventRepository)
        {
            _eventRepository = eventRepository;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator,Hr,Employee")]
        public async Task<ActionResult<List<Event>>> GetAllEvents()
        {
            var events = await _eventRepository.GetAll();
            if (events.Count > 0)
            {
                return Ok(events);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator,Hr,Employee")]
        public async Task<ActionResult<Event>> GetEventDetails(int id)
        {
            var @event = await _eventRepository.GetDetails(id);
            if (@event != null)
            {
                return Ok(@event);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "Hr")]
        public async Task<ActionResult<int>> AddEvent(Event @event)
        {
            if (ModelState.IsValid)
            {
                int result = await _eventRepository.Insert(@event);
                if (result > 0)
                {
                    return CreatedAtAction("GetEventDetails", new { id = @event.EventId }, @event);
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "Hr")]
        public async Task<ActionResult<int>> UpdateEvent(Event @event)
        {
            if (ModelState.IsValid)
            {
                var result = await _eventRepository.Update(@event);

                if (result > 0)
                {
                    return NoContent();
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator")]
        public async Task<ActionResult<int>> DeleteEvent(int id)
        {
            var result = await _eventRepository.Delete(id);
            if (result > 0)
            {
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
    }
}
