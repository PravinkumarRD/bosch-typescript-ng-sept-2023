﻿using Bajaj.Events.Dal;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Mvc;
using BCrypt.Net;
using Bajaj.Events.Api.Jwt;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Bajaj.Events.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ICommonRepository<Role> _roleRepository;
        private readonly ICommonRepository<User> _userRepository;
        private readonly ISecurity _security;
        private readonly ITokenManager _tokenManager;
        public UsersController(ICommonRepository<User> userRepository, ISecurity security, ICommonRepository<Role> roleRepository,ITokenManager tokenManager)
        {
            _userRepository = userRepository;
            _security = security;
            _roleRepository = roleRepository;
            _tokenManager = tokenManager;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<User>>> GetAllUsers()
        {
            var users = await _userRepository.GetAll();
            if (users.Count > 0)
            {
                return Ok(users);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<User>> GetUserDetails(int id)
        {
            var user = await _userRepository.GetDetails(id);
            if (user != null)
            {
                return Ok(user);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost("RegisterUser")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> AddUser(User user)
        {
            if (ModelState.IsValid)
            {
                var hashedPassword = BCrypt.Net.BCrypt.HashPassword(user.Password);
                user.Password = hashedPassword;
                int result = await _userRepository.Insert(user);
                if (result > 0)
                {
                    return CreatedAtAction("GetUserDetails", new { id = user.UserId }, user);
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<int>> UpdateUser(User user)
        {
            if (ModelState.IsValid)
            {
                var result = await _userRepository.Update(user);

                if (result > 0)
                {
                    return NoContent();
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<int>> DeleteUser(int id)
        {
            var result = await _userRepository.Delete(id);
            if (result > 0)
            {
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPost("CheckCredentials")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<User>> CheckCredentials(User user)
        {
            AuthResponse authResponse = new AuthResponse();
            var existingUser = await _security.VerifyCredentials(user);
            if (existingUser!=null)
            {
                var result = BCrypt.Net.BCrypt.Verify(user.Password, existingUser.Password);
                if (result)
                {
                    authResponse.IsAuthenticated = true;
                    authResponse.UserName = existingUser.Email;
                    var role = await _roleRepository.GetDetails(existingUser.RoleId);
                    authResponse.RoleName = role.RoleName;
                    authResponse.Token = _tokenManager.GenerateToken(authResponse);
                    return Ok(authResponse);
                }
                else
                {
                    return Ok(authResponse);
                }
            }
            else
            {
                return NotFound(authResponse);
            }
        } 
    }
}
