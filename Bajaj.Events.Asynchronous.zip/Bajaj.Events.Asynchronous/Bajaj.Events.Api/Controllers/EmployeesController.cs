﻿using Bajaj.Events.Dal;
using Bajaj.Events.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bajaj.Events.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors(policyName: "BajajCorsPolicy")]
    public class EmployeesController : ControllerBase
    {
        private readonly ICommonRepository<Employee> _employeeRepository;

        public EmployeesController(ICommonRepository<Employee> employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator,Hr,Employee")]
        public async Task<ActionResult<List<Employee>>> GetAllEmployees()
        {
            var employees = await _employeeRepository.GetAll();
            if (employees.Count > 0)
            {
                return Ok(employees);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator,Hr,Employee")]
        public async Task<ActionResult<Employee>> GetEmployeeDetails(int id)
        {
            var employee = await _employeeRepository.GetDetails(id);
            if (employee != null)
            {
                return Ok(employee);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "Administrator,Hr")]
        public async Task<ActionResult<int>> AddEmployee(Employee employee)
        {
            if (ModelState.IsValid)
            {
                int result = await _employeeRepository.Insert(employee);
                if (result > 0)
                {
                    return CreatedAtAction("GetEmployeeDetails", new { id = employee.EmployeeId }, employee);
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "Administrator")]
        public async Task<ActionResult<int>> UpdateEmployee(Employee employee)
        {
            if (ModelState.IsValid)
            {
                var result = await _employeeRepository.Update(employee);

                if (result > 0)
                {
                    return NoContent();
                }
                else
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }
        [HttpDelete("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize(Roles = "Administrator")]
        public async Task<ActionResult<Employee>> DeleteEmployee(int id)
        {
            var result = await _employeeRepository.Delete(id);
            if (result > 0)
            {
                var employee = await _employeeRepository.GetDetails(id);
                return Ok(employee);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
