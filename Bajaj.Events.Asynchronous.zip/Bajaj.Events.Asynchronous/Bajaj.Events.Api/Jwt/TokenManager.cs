﻿using Bajaj.Events.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Bajaj.Events.Api.Jwt
{
    public class TokenManager : ITokenManager
    {
        private readonly IConfiguration _config;
        private SymmetricSecurityKey _key;
        public TokenManager(IConfiguration config)
        {
            _config = config;
            _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["BajajJwtSettings:Secret"]));
        }

        public string GenerateToken(AuthResponse user)
        {
            var claims = new List<Claim>{
               new Claim(JwtRegisteredClaimNames.Name,user.UserName),
               new Claim(ClaimTypes.Role,user.RoleName)
           };
            var credentials = new SigningCredentials(_key, SecurityAlgorithms.HmacSha256);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddMinutes(60),
                SigningCredentials = credentials,

            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
