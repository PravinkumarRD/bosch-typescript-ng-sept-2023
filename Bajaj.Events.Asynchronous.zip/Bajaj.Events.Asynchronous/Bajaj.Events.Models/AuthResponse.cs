﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bajaj.Events.Models
{
    public class AuthResponse
    {
        public bool IsAuthenticated { get; set; }
        public string? UserName { get; set; }
        public string? RoleName { get; set; }
        public string? Token { get; set; }
    }
}
