﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bajaj.Events.Dal
{
    public interface ICommonRepository<T>
    {
        Task<List<T>> GetAll();
        Task<T> GetDetails(int id);
        Task<int> Insert(T item);
        Task<int> Update(T item);
        Task<int> Delete(int id);
    }
}
