﻿using Bajaj.Events.Models;

namespace Bajaj.Events.Dal
{
    public interface ISecurity
    {
        Task<User> VerifyCredentials(User user);
    }
}
