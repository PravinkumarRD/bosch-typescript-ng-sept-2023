﻿using Bajaj.Events.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bajaj.Events.Dal
{
    public class EventManagementDbContext:DbContext
    {
        public EventManagementDbContext()
        {

        }
        public EventManagementDbContext(DbContextOptions options):base(options)
        {

        }
        public DbSet<Employee>  Employees { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=localhost; Database=BajajEventsDb;Trusted_Connection=true;TrustServerCertificate=True");
            }
            
        }
    }
}
