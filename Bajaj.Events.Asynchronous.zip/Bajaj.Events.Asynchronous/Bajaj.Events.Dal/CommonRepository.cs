﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bajaj.Events.Dal
{
    public class CommonRepository<T> : ICommonRepository<T> where T : class
    {
        private readonly EventManagementDbContext _dbContext;
        private DbSet<T> _dbSet;
        //It is Dependency Injection
        public CommonRepository(EventManagementDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<T>();
        }
        //The method will return a Task with result. In this case, it is collection of T. For Example Collection of Employees Task<List<Employee>>
        public async Task<List<T>> GetAll()
        {
            return await _dbSet.ToListAsync();
        }

        public async Task<T> GetDetails(int id)
        {
            return await _dbSet.FindAsync(id);
        }      

        public async Task<int> Insert(T item)
        {
            _dbSet.Add(item);
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> Update(T item)
        {
            _dbSet.Attach(item);
            _dbContext.Entry(item).State = EntityState.Modified;
            return await _dbContext.SaveChangesAsync();
        }
        //You can not use await keyword without async method. Using await keyword, you extract the result of Task. For Example if you await on Task<Employee>, with await you will receive Employee Object. Or Task<List<Employee>> with await you will receive List<Employee>
        public async Task<int> Delete(int id)
        {
            _dbContext.Remove(await GetDetails(id));    
            return await _dbContext.SaveChangesAsync();
        }
    }
}
