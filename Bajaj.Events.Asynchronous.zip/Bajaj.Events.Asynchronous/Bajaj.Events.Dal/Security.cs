﻿using Bajaj.Events.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bajaj.Events.Dal
{
    public class Security : ISecurity
    {
        private readonly EventManagementDbContext _dbContext;
        public Security(EventManagementDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<User> VerifyCredentials(User user)
        {
            return await _dbContext.Users.SingleOrDefaultAsync(existingUser=>existingUser.Email== user.Email);
        }
    }
}
