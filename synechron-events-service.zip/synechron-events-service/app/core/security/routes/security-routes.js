const express = require('express');

const { checkCredentials } = require('../services/security-service');

const securityRoutes = express.Router();

securityRoutes.post('/authenticate', async (request, response) => {
    const credentials = request.body;
    console.log(credentials);
    try {
        const result = await checkCredentials(credentials);
        response.json(result);
    } catch (error) {
        response.json(error);
    }
});

module.exports = securityRoutes;