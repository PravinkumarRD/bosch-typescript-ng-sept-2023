const { getAllEvents, getEventDetails, insertNewEvent } = require('../dal/events-dal');

async function getAllSynechronEvents() {
    return await getAllEvents();
}
async function getSynechronEventDetails(id) {
    return await getEventDetails(id);
}
async function registerNewEvent(event) {
    return await insertNewEvent(event);
}

module.exports = {
    getAllSynechronEvents,
    getSynechronEventDetails,
    registerNewEvent
}