const { MongoClient } = require('mongodb');
const client = new MongoClient(process.env.CONNECTION_STRING);

async function getAllEvents() {
    try {
        await client.connect();
        const db = client.db(process.env.DATABASE_NAME);
        const collection = db.collection('events');
        const events = collection.find().toArray();
        return await events;
    } catch (error) {
        throw new Error(error);
    }
    finally {
        client.close();
    }
}
async function getEventDetails(eventId) {
    try {
        await client.connect();
        const db = client.db(process.env.DATABASE_NAME);
        const collection = db.collection('events');
        const event = collection.findOne({ eventId })
        return await event;
    } catch (error) {
        throw new Error(error);
    }
    finally {
        client.close();
    }
}
async function insertNewEvent(event) {
    try {
        const newEvent = {
            ...event,
            eventId: Number.parseInt(event.eventId),
            fees: Number.parseInt(event.fees),
            seatsFilled: Number.parseInt(event.seatsFilled),
            startDate: new Date(event.startDate),
            endDate: new Date(event.endDate),
            logo: "images/noimage.png"
        };
        await client.connect();
        const db = client.db(process.env.DATABASE_NAME);
        const collection = db.collection('events');
        return await collection.insertOne(newEvent);
    } catch (error) {
        throw new Error(error);
    }
    finally {
        client.close();
    }
}
module.exports = {
    getAllEvents,
    getEventDetails,
    insertNewEvent
}