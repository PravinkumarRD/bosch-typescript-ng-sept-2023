const jwt = require('jsonwebtoken');

const tokenAuthorization = function (request, response, next) {
    let token = request.body.token || request.query.token || request.headers['x-bosch-token'];
    if (token) {
        jwt.verify(token, process.env.TOKEN_SECRET, (err, decoded) => {
            if (err) {
                response.json({
                    message: 'Your token is expired or invalid! Please re-login to generate a new token!'
                });
                return;
            }
            next();
        })
    } else {
        response.json({
            message: 'We did not receive the token! Please pass the token with your request!'
        }).status(401);
    }
}

module.exports = {
    tokenAuthorization
}