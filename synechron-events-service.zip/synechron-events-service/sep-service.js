const express = require('express');
require('dotenv').config();
const cors=require("cors");

const employeesRoutes = require('./app/core/employees/routes/employees-routes');
const eventsRoutes = require('./app/core/events/routes/events-routes');
const securityRoutes = require('./app/core/security/routes/security-routes');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const PORT = process.env.PORT || 9000;

//http://localhost:9090/api/employees
//http://localhost:9090/api/events
app.use('/api/employees', employeesRoutes);
app.use('/api/events', eventsRoutes);
//http://localhost:9090/bosch/authenticate
app.use('/bosch', securityRoutes);
app.listen(PORT, () => console.log(`Express Service is running on PORT - ${PORT}`));
