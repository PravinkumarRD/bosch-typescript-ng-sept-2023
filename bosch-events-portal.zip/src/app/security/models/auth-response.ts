export class AuthResponse {
    success: boolean;
    token: string;
    role: string;
    message: string;
}
