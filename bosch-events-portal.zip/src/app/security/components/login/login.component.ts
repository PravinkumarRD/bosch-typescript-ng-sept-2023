import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { AuthResponse } from "../../models/auth-response";
import { User } from "../../models/user";

import { SecurityService } from "../../services/security.service";

@Component({
  selector: 'bosch-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _activatedRoute: ActivatedRoute, private _securityService: SecurityService, private _router: Router) {

  }

  user: User = new User();
  private _authResponse: AuthResponse;
  private _returnUrl: string;
  ngOnInit(): void {
    this._returnUrl = this._activatedRoute.snapshot.queryParams['returnurl'];
    console.log(this._returnUrl)

  }

  onCredentialsSubmit(): void {
    this._securityService.authenticateUser(this.user).subscribe({
      next: response => {
        this._authResponse = response;
        if (this._authResponse.success === true) {
          sessionStorage.setItem('token', this._authResponse.token);
          sessionStorage.setItem('role', this._authResponse.role);
          if (this._returnUrl) {
            this._router.navigate([this._returnUrl]);
          }else{
            this._router.navigate(['/home']);
          }
        }
      }
    });
  }
}
