import { GlobalDatePipe } from './global-date.pipe';

describe('GlobalDatePipe', () => {
  it('create an instance', () => {
    const pipe = new GlobalDatePipe();
    expect(pipe).toBeTruthy();
  });
});
