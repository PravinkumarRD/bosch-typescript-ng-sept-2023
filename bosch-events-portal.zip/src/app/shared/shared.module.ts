import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GlobalDatePipe } from './pipes/global-date.pipe';
import { ResourceNotFoundComponent } from './components/resource-not-found/resource-not-found.component';



@NgModule({
  declarations: [
    GlobalDatePipe,
    ResourceNotFoundComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    GlobalDatePipe
  ]
})
export class SharedModule { }
