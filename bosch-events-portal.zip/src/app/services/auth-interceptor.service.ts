import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthInterceptor implements HttpInterceptor {
  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.includes('/api/')) {
      console.log('Intercepted HttpReqest Call!');
      const headers = req.headers
        .set('Content-Type', 'application/json')
        .set('x-bosch-token', `${sessionStorage.getItem('token')}`);
      const authReq = req.clone({ headers });
      return next.handle(authReq);
    }else{
      return next.handle(req);
    }

  }
}

//Microsoft Web API
/*
const headers = req.headers
      .set('Content-Type', 'application/json')
      .set('Authorization', `Bearer ${sessionStorage.getItem('token')}`);
*/