import { EventRegistrationModel } from './event-registration-model';

describe('EventRegistrationModel', () => {
  it('should create an instance', () => {
    expect(new EventRegistrationModel()).toBeTruthy();
  });
});
