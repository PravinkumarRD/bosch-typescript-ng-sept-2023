import { FilterEventByNamePipe } from './filter-event-by-name.pipe';

describe('FilterEventByNamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterEventByNamePipe();
    expect(pipe).toBeTruthy();
  });
});
