import { TestBed } from '@angular/core/testing';
import { FilterEventByNamePipe } from './filter-event-by-name.pipe';

describe('FilterEventByNamePipe', () => {
  let pipe: FilterEventByNamePipe;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [FilterEventByNamePipe] });
    pipe = TestBed.inject(FilterEventByNamePipe);
  });

  it('can load instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('transforms X to Y', () => {
    const value: any = 'X';
    const args: string[] = [];
    expect(pipe.transform(value, args)).toEqual('Y');
  });
});
