import { Component } from '@angular/core';

import { EventRegistrationModel } from "../../models/event-registration-model";

@Component({
  selector: 'bosch-register-event',
  templateUrl: './register-event.component.html',
  styleUrls: ['./register-event.component.css']
})
export class RegisterEventComponent {
  title: string = "Bosch New Event Registration Form!";
  registerEvent: EventRegistrationModel = new EventRegistrationModel();

  onEventRegistration():void{
    console.log(this.registerEvent.eventForm.value);
  }
}
