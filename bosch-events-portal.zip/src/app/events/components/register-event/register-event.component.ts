import { Component } from '@angular/core';

@Component({
  selector: 'bosch-register-event',
  templateUrl: './register-event.component.html',
  styleUrls: ['./register-event.component.css']
})
export class RegisterEventComponent {

}
