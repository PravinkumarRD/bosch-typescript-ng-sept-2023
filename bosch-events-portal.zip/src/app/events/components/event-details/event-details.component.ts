import { Component } from '@angular/core';

@Component({
  selector: 'bosch-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent {

}
