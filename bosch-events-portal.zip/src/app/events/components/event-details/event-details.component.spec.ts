import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventsService } from '../../services/events.service';
import { EventDetailsComponent } from './event-details.component';

describe('EventDetailsComponent', () => {
  let component: EventDetailsComponent;
  let fixture: ComponentFixture<EventDetailsComponent>;

  beforeEach(() => {
    const activatedRouteStub = () => ({ snapshot: { params: {} } });
    const eventsServiceStub = () => ({
      getEventDetails: arg => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [EventDetailsComponent],
      providers: [
        { provide: ActivatedRoute, useFactory: activatedRouteStub },
        { provide: EventsService, useFactory: eventsServiceStub }
      ]
    });
    fixture = TestBed.createComponent(EventDetailsComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`title has default value`, () => {
    expect(component.title).toEqual(`Details Of - `);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const eventsServiceStub: EventsService = fixture.debugElement.injector.get(
        EventsService
      );
      spyOn(eventsServiceStub, 'getEventDetails').and.callThrough();
      component.ngOnInit();
      expect(eventsServiceStub.getEventDetails).toHaveBeenCalled();
    });
  });
});
