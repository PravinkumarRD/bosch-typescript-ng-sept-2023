import { Component } from '@angular/core';

@Component({
  selector: 'bosch-general-home',
  templateUrl: './general-home.component.html',
  styleUrls: ['./general-home.component.css']
})
export class GeneralHomeComponent {

}
