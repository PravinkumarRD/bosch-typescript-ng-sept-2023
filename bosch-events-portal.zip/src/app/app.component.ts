import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = "Welcome To Bosch Events Portal!";
  subTitle: string = "Designed and Developed by Bosch Employees!";
  myCMS: string = "Hello Bosch - <alert>This is very bad code</alert>! Will this work?";
  isDisabled: boolean = false;
  changeTitle():void{
    this.title="Welcome To Bosch Events Portal! Bangalore!";
  }
}
