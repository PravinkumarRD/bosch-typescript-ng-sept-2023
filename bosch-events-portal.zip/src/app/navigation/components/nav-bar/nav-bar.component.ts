import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'bosch-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {
  constructor(private _router: Router) {

  }
  logo: string = '../images/logo.png';
  token: string | null;
  role: string | null;
  ngOnInit(): void {
    this._router.events.subscribe({
      next: events => {
        this.token = sessionStorage.getItem('token');
        this.role = sessionStorage.getItem('role');
      }
    });
  }
  logout():void{
    sessionStorage.clear();
  }
}
