import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";

import { GeneralHomeComponent } from './home/components/general-home/general-home.component';
import { LoginComponent } from './security/components/login/login.component';
import { ResourceNotFoundComponent } from './shared/components/resource-not-found/resource-not-found.component';


const appRoutes: Routes = [
  {
    path: '',
    component: GeneralHomeComponent
  },
  {
    path: 'home',
    component: GeneralHomeComponent
  },
  {
    path: 'employees',
    loadChildren: () => import("./employees/employees.module").then(m => m.EmployeesModule)
  },
  {
    path: 'events',
    loadChildren: () => import("./events/events.module").then(m => m.EventsModule)
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path:'**',
    component:ResourceNotFoundComponent
  }
];


@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
