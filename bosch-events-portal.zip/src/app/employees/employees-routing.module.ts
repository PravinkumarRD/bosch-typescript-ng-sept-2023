import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { EmployeesListComponent } from './components/employees-list/employees-list.component';

const employeeRoutes: Routes = [
  {
    path: '',
    component: EmployeesListComponent
  },
  {
    path: 'new',
    component: EmployeesListComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(employeeRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class EmployeesRoutingModule { }
