import { TokenGuard } from './token-guard';

describe('TokenGuard', () => {
  it('should create an instance', () => {
    expect(new TokenGuard()).toBeTruthy();
  });
});
