import { inject } from '@angular/core';
import { Router } from "@angular/router";
import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot } from '@angular/router';

export const TokenGuard: CanActivateFn = (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
) => {
    let token = sessionStorage.getItem('token');
    if (token) {
        return true;
    } else {
        const _router = inject(Router);
        _router.navigate(['/login'], {
            queryParams: {
                returnurl: state.url
            }
        });
        return false;
    }

}
